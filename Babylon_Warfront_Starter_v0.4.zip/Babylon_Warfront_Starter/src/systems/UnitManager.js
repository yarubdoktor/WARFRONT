import { MeshBuilder, StandardMaterial, Color3, Vector3, Animation } from '@babylonjs/core';

export class UnitManager {
  constructor(scene, shadowGenerator) {
    this.scene = scene; this.units = []; this.selected = null;
    this.materials = {
      friendly: this.makeMat('friendly-unit', new Color3(.22,.42,.62)),
      enemy: this.makeMat('enemy-unit', new Color3(.58,.22,.17)),
      trim: this.makeMat('unit-trim', new Color3(.72,.62,.40))
    };
    this.spawnSquad('friendly', new Vector3(-5,0,12), 4, shadowGenerator);
    this.spawnSquad('enemy', new Vector3(8,0,-25), 3, shadowGenerator);
  }
  makeMat(name,color){const m=new StandardMaterial(name,this.scene);m.diffuseColor=color;m.specularColor=new Color3(.2,.2,.2);return m;}
  spawnSquad(team, center, count, shadows){
    for(let i=0;i<count;i++){
      const root=MeshBuilder.CreateCapsule(`${team}-soldier-${i+1}`,{height:1.65,radius:.34,tessellation:8},this.scene);
      root.position.set(center.x+(i%2)*1.25, .9, center.z+Math.floor(i/2)*1.45);
      root.material=this.materials[team];root.visibility=0.001;root.metadata={unit:true,team,hp:100,maxHp:100,selected:false};root.isPickable=true;
      const head=MeshBuilder.CreateSphere(`${root.name}-head`,{diameter:.48,segments:8},this.scene);head.parent=root;head.position.y=.72;head.material=this.materials.trim;head.isPickable=false;head.visibility=.001;
      const pack=MeshBuilder.CreateBox(`${root.name}-pack`,{width:.52,height:.62,depth:.24},this.scene);pack.parent=root;pack.position.set(0,.08,-.29);pack.material=this.materials[team];pack.isPickable=false;pack.visibility=.001;
      shadows.addShadowCaster(root);this.units.push(root);
    }
  }
  select(unit){this.clearSelection();if(!unit?.metadata?.unit)return;this.selected=unit;unit.metadata.selected=true;unit.scaling.setAll(1.12);this.scene.getMeshByName('selection-ring')?.dispose();const ring=MeshBuilder.CreateTorus('selection-ring',{diameter:1.5,thickness:.07,tessellation:32},this.scene);ring.position.set(unit.position.x,.08,unit.position.z);ring.rotation.x=Math.PI/2;ring.material=this.makeMat('selection-ring-mat',new Color3(.95,.72,.28));ring.isPickable=false;this.selectionRing=ring;this.updateHud();}
  clearSelection(){if(this.selected){this.selected.metadata.selected=false;this.selected.scaling.setAll(1);};this.selected=null;this.selectionRing?.dispose();this.selectionRing=null;this.updateHud();}
  moveSelected(point){if(!this.selected)return;this.selected.metadata.destination=point.clone();}
  update(dt){for(const u of this.units){const d=u.metadata.destination;if(!d)continue;const delta=d.subtract(u.position);delta.y=0;if(delta.length()<.35){u.metadata.destination=null;continue;}const step=Math.min(delta.length(),dt*3.1);u.position.addInPlace(delta.normalize().scale(step));u.rotation.y=Math.atan2(delta.x,delta.z);if(u===this.selected&&this.selectionRing)this.selectionRing.position.set(u.position.x,.08,u.position.z);}}
  updateHud(){const el=document.getElementById('unit-status');if(el)el.textContent=this.selected?`وحدة ${this.selected.metadata.team==='friendly'?'صديقة':'معادية'} · ${this.selected.metadata.hp} صحة`:'لا توجد وحدة محددة';}
  getFriendly(){return this.units.filter(u=>u.metadata.team==='friendly');}
  getEnemies(){return this.units.filter(u=>u.metadata.team==='enemy');}
}
