import { SceneLoader, TransformNode, Vector3 } from '@babylonjs/core';
import '@babylonjs/loaders/glTF';

// Gobkit Free Character Pack Vol.4 — CC0 1.0, rigged GLB with named clips.
// Source manifest: https://gobkit.com/api/free
const SOLDIER_MODELS = {
  friendly: {
    name: 'Rifleman',
    url: 'https://gobkit.com/freebies/human004/Rifleman.glb',
  },
  enemy: {
    name: 'ArmySniper',
    url: 'https://gobkit.com/freebies/human004/ArmySniper.glb',
  },
};

const LOOPING = new Set(['Idle', 'Walk', 'Run']);

export class SoldierVisualSystem {
  constructor(scene, units) {
    this.scene = scene;
    this.units = units;
    this.templates = new Map();
    this.visuals = new Map();
    this.failed = [];
    this.ready = this.loadTemplatesAndAttach();
  }

  async loadTemplate(team, asset) {
    const slash = asset.url.lastIndexOf('/') + 1;
    const rootUrl = asset.url.slice(0, slash);
    const fileName = asset.url.slice(slash);
    const container = await SceneLoader.LoadAssetContainerAsync(rootUrl, fileName, this.scene);
    this.templates.set(team, container);
    return container;
  }

  async loadTemplatesAndAttach() {
    const entries = Object.entries(SOLDIER_MODELS);
    await Promise.all(entries.map(async ([team, asset]) => {
      try {
        await this.loadTemplate(team, asset);
      } catch (error) {
        this.failed.push({ team, error: String(error) });
        console.warn(`[SoldierVisualSystem] ${asset.name} unavailable; using fallback unit`, error);
      }
    }));

    for (const unit of this.units.units) {
      const container = this.templates.get(unit.metadata.team);
      if (container) this.attachUnit(unit, container, unit.metadata.team);
    }

    const status = document.getElementById('soldier-status');
    const loaded = [...this.visuals.values()].length;
    if (status) status.textContent = `${loaded}/${this.units.units.length} جندي بنموذج متحرك`;
    return loaded;
  }

  attachUnit(unit, container, team) {
    // Babylon's AssetContainer instancing clones skeletons correctly for skinned GLBs.
    const instance = container.instantiateModelsToScene(
      name => `${name}-${team}-${unit.uniqueId}`,
      false,
      { doNotInstantiate: false },
    );
    const anchor = new TransformNode(`soldier-visual-${unit.uniqueId}`, this.scene);
    anchor.parent = unit;
    anchor.position = new Vector3(0, -0.9, 0);
    anchor.scaling.setAll(0.9);

    for (const node of instance.rootNodes) {
      node.parent = anchor;
      node.position.addInPlace(new Vector3(0, 0, 0));
    }

    const allMeshes = anchor.getChildMeshes(false);
    for (const mesh of allMeshes) {
      mesh.isPickable = true;
      mesh.metadata = { ...(mesh.metadata || {}), unit: true, unitRoot: unit, team };
      mesh.receiveShadows = true;
    }

    // Hide the primitive placeholder while retaining its collision/picking proxy.
    unit.visibility = 0.001;
    unit.isPickable = true;
    unit.metadata.visualAnchor = anchor;

    const groups = new Map((instance.animationGroups || []).map(group => [group.name.toLowerCase(), group]));
    this.visuals.set(unit.uniqueId, { unit, anchor, groups, current: null, team, forcedUntil: 0 });
    this.play(unit, 'Idle');
  }

  play(unit, clipName) {
    const visual = this.visuals.get(unit.uniqueId);
    if (!visual) return false;
    const key = clipName.toLowerCase();
    const next = visual.groups.get(key) || visual.groups.get(key.replace(/^./, c => c.toLowerCase()));
    if (!next) return false;
    if (visual.current === next && next.isPlaying) return true;
    visual.groups.forEach(group => group.stop());
    next.start(LOOPING.has(clipName), 1.0);
    visual.current = next;
    return true;
  }

  trigger(unit, clipName, durationMs = 550) {
    const visual = this.visuals.get(unit.uniqueId);
    if (!visual) return false;
    visual.forcedUntil = performance.now() + durationMs;
    return this.play(unit, clipName);
  }

  update() {
    for (const visual of this.visuals.values()) {
      const { unit } = visual;
      if (unit.isDisposed()) continue;
      if (performance.now() < visual.forcedUntil) continue;
      const meta = unit.metadata || {};
      const target = meta.target;
      const moving = !!meta.destination;
      if (target && !target.isDisposed()) {
        const distance = Vector3.Distance(unit.position, target.position);
        this.play(unit, distance <= 7 ? 'Attack' : 'Run');
      } else if (moving) {
        this.play(unit, 'Walk');
      } else {
        this.play(unit, 'Idle');
      }
    }
  }

  dispose() {
    for (const visual of this.visuals.values()) {
      visual.groups.forEach(group => group.dispose());
      visual.anchor.dispose(false, true);
    }
    this.visuals.clear();
    this.templates.forEach(container => container.dispose());
    this.templates.clear();
  }
}
