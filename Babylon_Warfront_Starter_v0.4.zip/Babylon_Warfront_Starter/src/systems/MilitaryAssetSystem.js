import { SceneLoader, Vector3 } from '@babylonjs/core';
import '@babylonjs/loaders/glTF';

const VEHICLE_ASSETS = [
  { id: 'main-battle-tank', name: 'Main Battle Tank', url: 'https://cdn.3dassets.dev/assets/23667/v1/', position: new Vector3(18, 0, 10), scale: 1.35 },
  { id: 'tracked-apc', name: 'Tracked APC', url: 'https://cdn.3dassets.dev/assets/23668/v1/', position: new Vector3(30, 0, 10), scale: 1.45 },
  { id: 'rocket-launcher', name: 'Mobile Rocket Launcher', url: 'https://cdn.3dassets.dev/assets/23671/v1/', position: new Vector3(18, 0, -5), scale: 1.4 },
  { id: 'supply-truck', name: 'Supply Truck', url: 'https://cdn.3dassets.dev/assets/23674/v1/', position: new Vector3(31, 0, -7), scale: 1.25 },
];

/** Loads CC0 GLB military vehicles from the source CDN. Models are cached by Babylon's scene once loaded. */
export class MilitaryAssetSystem {
  constructor(scene, shadowGenerator) {
    this.scene = scene;
    this.shadowGenerator = shadowGenerator;
    this.loaded = [];
    this.failed = [];
    this.ready = this.loadInitialVehicles();
  }

  async loadInitialVehicles() {
    for (const asset of VEHICLE_ASSETS) {
      try {
        const result = await SceneLoader.ImportMeshAsync('', asset.url, 'model.glb', this.scene);
        const root = result.meshes.find(mesh => mesh.name === '__root__') || result.meshes[0];
        if (!root) throw new Error('GLB did not contain a root mesh');
        root.name = `asset-${asset.id}`;
        root.position.copyFrom(asset.position);
        root.scaling.setAll(asset.scale);
        root.rotation.y = Math.PI;
        for (const mesh of result.meshes) {
          if (mesh !== root && mesh.getTotalVertices() > 0) {
            mesh.isPickable = true;
            mesh.metadata = { ...(mesh.metadata || {}), militaryAsset: asset.id, assetName: asset.name };
            this.shadowGenerator.addShadowCaster(mesh, true);
          }
        }
        this.loaded.push({ ...asset, root });
      } catch (error) {
        console.warn(`[MilitaryAssetSystem] Could not load ${asset.name}`, error);
        this.failed.push({ ...asset, error: String(error) });
      }
    }
    const status = document.getElementById('asset-status');
    if (status) status.textContent = `${this.loaded.length}/${VEHICLE_ASSETS.length} مركبات ثلاثية الأبعاد`;
    return this.loaded;
  }
}
