# WARFRONT — Babylon.js Tactical Prototype

A modular browser-based 3D strategy prototype. This is an evolving playable foundation, not a finished commercial game.

## Requirements
- Node.js 20+
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local Vite URL printed in the terminal. For a production bundle:
```bash
npm run build
npm run preview
```

## Implemented in this build
- Babylon.js scene, render loop, terrain, roads, rocks, lighting and shadow map.
- Tactical ArcRotate camera with custom pointer handling: one pointer orbits; two pointers pan and pinch-zoom; mouse wheel zoom remains available.
- Five selectable base buildings with contextual information and highlight.
- Friendly and enemy procedural soldier units (temporary meshes pending optimized GLB art).
- Unit selection, move orders by tapping/clicking terrain, basic close-range combat and health.
- Basic enemy AI that detects nearby friendly units and engages them.
- Field construction mode for a barracks or radar, placement bounds and overlap validation.
- Gold resource spending for construction; insufficient funds prevent placement.
- Responsive Arabic HUD and camera/build controls.

## Controls
- Mouse drag / one-finger drag: orbit camera.
- Two-finger drag: pan camera; pinch: zoom.
- Mouse wheel: zoom.
- Select a friendly unit, then tap/click open terrain to move it.
- Select a friendly unit, then select an enemy to attack.
- Build a barracks/radar, move the preview onto valid ground, then tap/click to place; cancel to exit placement mode.
- Select a building to inspect it.

## Known limitations / next work
- Soldier meshes are placeholders; replace with optimized, rigged GLB assets and animation state machine.
- Combat is a lightweight prototype (range, cooldown, health); no projectile ballistics, cover, armor classes, audio or polished VFX yet.
- AI is a simple proximity engagement behavior, not strategic pathfinding.
- Construction currently supports two field structures and basic collision-distance checks only.
- No persistent save, server-authoritative multiplayer, matchmaking, or APK packaging yet.
- Touch gesture behavior and performance must be verified on actual target phones before calling this milestone validated.

## Project structure
- `src/core`: game lifecycle and scene orchestration.
- `src/world`: terrain and environment generation.
- `src/entities`: base building entities.
- `src/systems`: camera, units, selection, construction, resources, combat and AI.
- `src/ui`: responsive HUD styling.

## v0.3 — Free military GLB integration

Four military vehicle models are now loaded into the battlefield from 3DAssets.dev's **Tanks, Military Vehicles and Field Camp** pack:

- Main Battle Tank — https://cdn.3dassets.dev/assets/23667/v1/model.glb
- Tracked APC — https://cdn.3dassets.dev/assets/23668/v1/model.glb
- Mobile Rocket Launcher — https://cdn.3dassets.dev/assets/23671/v1/model.glb
- Supply Truck — https://cdn.3dassets.dev/assets/23674/v1/model.glb

**License:** CC0 1.0 Universal; commercial use and modification allowed, attribution not required. Source pack: https://3dassets.dev/packs/armoured-column-and-field-camp

**Important technical notes:** these four source models are static meshes (no built-in rigs or animation clips), use metre units and +Y up, and are fetched from the source CDN at runtime. An internet connection is therefore required to display them. Vehicle movement, turret articulation, wheel/track animation, collision, and combat integration are separate gameplay tasks and are not claimed complete in this version. The current models are lightweight geometry and serve as the first licensed vehicle set, not final AAA hero assets.


## v0.4 — Animated infantry
- Added two CC0 1.0 rigged infantry GLBs: Rifleman (friendly) and ArmySniper (enemy).
- Uses Babylon AssetContainer instancing to create skeleton-safe copies for each unit.
- Connects Idle / Walk / Run / Attack / Hit / Death clips to unit movement and combat state.
- Keeps the existing primitive unit collider as a nearly invisible selection proxy.
- GLBs stream from Gobkit's public CDN; online access is required for the character models. If loading fails, the primitive fallback remains.
- See `docs/ASSET_CREDITS.md` for asset and license details.
