# Asset register

## Military vehicle pack
- Pack: Tanks, Military Vehicles and Field Camp
- Publisher: 3DAssets.dev
- License: CC0 1.0 Universal
- Source: https://3dassets.dev/packs/armoured-column-and-field-camp
- Runtime CDN models: Main Battle Tank (23667), Tracked APC (23668), Mobile Rocket Launcher (23671), Supply Truck (23674)
- License permits commercial use and modification without attribution.
- Source metadata states the models are static geometry without rigs or animation clips.


## Animated modern infantry pack
- Pack: Gobkit Free Character Pack Vol.4
- Publisher: Gobkit
- License: CC0 1.0 Universal (commercial use and modification; attribution not required).
- Source / manifest: https://gobkit.com/api/free
- Browse: https://gobkit.com/freebies
- Models integrated at runtime: Rifleman (friendly) and ArmySniper (enemy).
- Format: GLB / glTF 2.0, rigged skinned meshes.
- Named clips: Idle, Walk, Run, Death, Hit, Attack, Special (30 FPS).
- The source manifest explicitly specifies separate named clips and skeleton-aware instancing for multiple copies.
- Models are streamed from the publisher CDN; an internet connection is required unless the assets are later bundled locally.
