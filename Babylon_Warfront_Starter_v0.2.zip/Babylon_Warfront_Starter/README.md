# WARFRONT — Babylon.js Tactical Prototype

A modular browser-based 3D strategy prototype. This is an evolving playable foundation, not a finished commercial game.

## Requirements
- Node.js 20+
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local Vite URL printed in the terminal. For a production bundle:
```bash
npm run build
npm run preview
```

## Implemented in this build
- Babylon.js scene, render loop, terrain, roads, rocks, lighting and shadow map.
- Tactical ArcRotate camera with custom pointer handling: one pointer orbits; two pointers pan and pinch-zoom; mouse wheel zoom remains available.
- Five selectable base buildings with contextual information and highlight.
- Friendly and enemy procedural soldier units (temporary meshes pending optimized GLB art).
- Unit selection, move orders by tapping/clicking terrain, basic close-range combat and health.
- Basic enemy AI that detects nearby friendly units and engages them.
- Field construction mode for a barracks or radar, placement bounds and overlap validation.
- Gold resource spending for construction; insufficient funds prevent placement.
- Responsive Arabic HUD and camera/build controls.

## Controls
- Mouse drag / one-finger drag: orbit camera.
- Two-finger drag: pan camera; pinch: zoom.
- Mouse wheel: zoom.
- Select a friendly unit, then tap/click open terrain to move it.
- Select a friendly unit, then select an enemy to attack.
- Build a barracks/radar, move the preview onto valid ground, then tap/click to place; cancel to exit placement mode.
- Select a building to inspect it.

## Known limitations / next work
- Soldier meshes are placeholders; replace with optimized, rigged GLB assets and animation state machine.
- Combat is a lightweight prototype (range, cooldown, health); no projectile ballistics, cover, armor classes, audio or polished VFX yet.
- AI is a simple proximity engagement behavior, not strategic pathfinding.
- Construction currently supports two field structures and basic collision-distance checks only.
- No persistent save, server-authoritative multiplayer, matchmaking, or APK packaging yet.
- Touch gesture behavior and performance must be verified on actual target phones before calling this milestone validated.

## Project structure
- `src/core`: game lifecycle and scene orchestration.
- `src/world`: terrain and environment generation.
- `src/entities`: base building entities.
- `src/systems`: camera, units, selection, construction, resources, combat and AI.
- `src/ui`: responsive HUD styling.
