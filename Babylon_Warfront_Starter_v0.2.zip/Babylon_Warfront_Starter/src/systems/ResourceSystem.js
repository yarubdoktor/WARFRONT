export class ResourceSystem {
  constructor(){this.values={gold:12500,steel:8200,fuel:4750};this.listeners=new Set();}
  canAfford(cost){return this.values.gold>=cost;}
  spend(cost){if(!this.canAfford(cost))return false;this.values.gold-=cost;this.emit();return true;}
  add(type,amount){if(!(type in this.values)||amount<=0)return;this.values[type]+=amount;this.emit();}
  subscribe(fn){this.listeners.add(fn);fn(this.values);return()=>this.listeners.delete(fn);}
  emit(){for(const fn of this.listeners)fn({...this.values});}
}
