import { Vector3 } from '@babylonjs/core';
export class AISystem {
  constructor(units,combat){this.units=units;this.combat=combat;this.timer=0;}
  update(dt){this.timer+=dt;if(this.timer<1.2)return;this.timer=0;const friendlies=this.units.getFriendly(),enemies=this.units.getEnemies();for(const enemy of enemies){if(enemy.metadata.target)continue;let nearest=null,best=Infinity;for(const f of friendlies){const d=Vector3.Distance(enemy.position,f.position);if(d<best){best=d;nearest=f;}}if(nearest&&best<30)this.combat.attack(enemy,nearest);}for(const friendly of friendlies){if(friendly.metadata.target)continue;let threat=null,dist=Infinity;for(const enemy of enemies){const d=Vector3.Distance(friendly.position,enemy.position);if(d<dist){dist=d;threat=enemy;}}if(threat&&dist<11&&threat.metadata.target)this.combat.attack(friendly,threat);}}
}
