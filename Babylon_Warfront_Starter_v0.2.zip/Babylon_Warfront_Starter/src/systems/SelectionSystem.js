import { Color3, HighlightLayer } from '@babylonjs/core';
export class SelectionSystem{
 constructor(scene,buildings){this.buildings=buildings;this.selected=null;this.highlight=new HighlightLayer('selection-highlight',scene);this.highlight.innerGlow=false;this.highlight.outerGlow=true;}
 selectFromMesh(mesh){const root=mesh.metadata?.buildingRoot||(mesh.metadata?.selectable?mesh:null);if(!root||!this.buildings.includes(root)){this.clear();return;}this.clear();this.selected=root;root.getChildMeshes().forEach(child=>this.highlight.addMesh(child,new Color3(.95,.68,.25)));document.getElementById('selection-name').textContent=root.metadata.label;document.getElementById('selection-detail').textContent=root.metadata.detail;document.getElementById('selection-card').classList.add('active');}
 clear(){if(this.selected)this.selected.getChildMeshes().forEach(child=>this.highlight.removeMesh(child));this.selected=null;document.getElementById('selection-name').textContent='لا يوجد تحديد';document.getElementById('selection-detail').textContent='انقر على أحد المباني';document.getElementById('selection-card').classList.remove('active');}
}
