import { PointerEventTypes, Vector3 } from '@babylonjs/core';
export class CameraController {
 constructor(scene,camera,canvas){this.scene=scene;this.camera=camera;this.canvas=canvas;this.pointers=new Map();this.lastCenter=null;this.lastDistance=0;this.bind();}
 bind(){this.scene.onPointerObservable.add(info=>{const e=info.event;if(info.type===PointerEventTypes.POINTERDOWN){this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.pointers.size===2){this.lastCenter=this.center();this.lastDistance=this.distance();} }
 else if(info.type===PointerEventTypes.POINTERUP||info.type===PointerEventTypes.POINTERDOUBLETAP){this.pointers.delete(e.pointerId);this.lastCenter=null;this.lastDistance=0;}
 else if(info.type===PointerEventTypes.POINTERMOVE){if(!this.pointers.has(e.pointerId))return;const prev=this.pointers.get(e.pointerId);this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.pointers.size===2){const c=this.center(),d=this.distance();if(this.lastCenter){const dx=c.x-this.lastCenter.x,dy=c.y-this.lastCenter.y;this.camera.inertialPanningX+=dx*.006;this.camera.inertialPanningY-=dy*.006;if(this.lastDistance>0)this.camera.radius=Math.max(this.camera.lowerRadiusLimit,Math.min(this.camera.upperRadiusLimit,this.camera.radius+(this.lastDistance-d)*.035));}this.lastCenter=c;this.lastDistance=d;}else if(this.pointers.size===1){const dx=e.clientX-prev.x,dy=e.clientY-prev.y;this.camera.inertialAlphaOffset+=dx*.006;this.camera.inertialBetaOffset+=dy*.004;}}});}
 center(){const p=[...this.pointers.values()];return{x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2};}
 distance(){const p=[...this.pointers.values()];return Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);}
}
