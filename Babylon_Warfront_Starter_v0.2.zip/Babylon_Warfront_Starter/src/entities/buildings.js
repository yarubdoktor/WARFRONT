import { MeshBuilder, StandardMaterial, Color3, TransformNode } from '@babylonjs/core';
function mat(scene,name,color){const m=new StandardMaterial(name,scene);m.diffuseColor=color;m.specularColor=new Color3(.35,.35,.32);m.specularPower=64;return m;}
function createBuilding(scene,shadows,c){
 const root=new TransformNode(c.id,scene);root.position.set(c.x,0,c.z);root.metadata={selectable:true,label:c.name,detail:c.detail};
 const concrete=mat(scene,c.id+'-concrete',new Color3(.39,.41,.39)),dark=mat(scene,c.id+'-dark',new Color3(.13,.17,.18)),accent=mat(scene,c.id+'-accent',new Color3(.49,.34,.19));
 const body=MeshBuilder.CreateBox(c.id+'-body',{width:c.width,height:c.height,depth:c.depth},scene);body.parent=root;body.position.y=c.height/2;body.material=concrete;
 const roof=MeshBuilder.CreateBox(c.id+'-roof',{width:c.width*1.08,height:.42,depth:c.depth*1.08},scene);roof.parent=root;roof.position.y=c.height+.2;roof.material=dark;
 const door=MeshBuilder.CreateBox(c.id+'-door',{width:c.width*.22,height:c.height*.48,depth:.12},scene);door.parent=root;door.position.set(0,c.height*.24,c.depth/2+.07);door.material=dark;
 const stripe=MeshBuilder.CreateBox(c.id+'-stripe',{width:c.width*.86,height:.16,depth:.08},scene);stripe.parent=root;stripe.position.set(0,c.height*.72,c.depth/2+.08);stripe.material=accent;
 const pad=MeshBuilder.CreateCylinder(c.id+'-foundation',{diameter:Math.max(c.width,c.depth)*1.25,height:.22,tessellation:48},scene);pad.parent=root;pad.position.y=.11;pad.material=dark;pad.isPickable=false;pad.receiveShadows=true;
 root.getChildMeshes().forEach(mesh=>{mesh.isPickable=true;mesh.metadata={selectable:true,buildingRoot:root};shadows.addShadowCaster(mesh);mesh.receiveShadows=true;});return root;
}
export function createBaseBuildings(scene,shadows){const configs=[
{id:'command-hq',name:'مركز القيادة',detail:'المبنى الرئيسي · المستوى 01',x:0,z:0,width:8,depth:7,height:4.1},
{id:'vehicle-depot',name:'مستودع المركبات',detail:'منشأة دعم لوجستي',x:-13,z:5,width:7,depth:6,height:3.2},
{id:'radar-station',name:'محطة الرادار',detail:'مراقبة المجال المحيط',x:13,z:4,width:6,depth:5,height:3},
{id:'barracks',name:'ثكنة الجنود',detail:'مركز تدريب الوحدات البرية',x:-11,z:-12,width:7,depth:6,height:3.3},
{id:'supply-depot',name:'مستودع الإمدادات',detail:'إدارة الموارد العسكرية',x:12,z:-12,width:7,depth:6,height:3}];return configs.map(c=>createBuilding(scene,shadows,c));}
