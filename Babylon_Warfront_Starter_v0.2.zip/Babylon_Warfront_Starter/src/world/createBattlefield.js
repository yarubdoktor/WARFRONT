import { MeshBuilder, StandardMaterial, Color3, VertexData } from '@babylonjs/core';
function heightAt(x,z){return Math.sin(x*.075)*.65+Math.cos(z*.09)*.48+Math.sin((x+z)*.045)*.42;}
function createTerrain(scene){
  const size=150, segments=100, positions=[], indices=[], uvs=[];
  for(let z=0;z<=segments;z++) for(let x=0;x<=segments;x++){
    const px=(x/segments-.5)*size,pz=(z/segments-.5)*size; positions.push(px,heightAt(px,pz),pz); uvs.push(x/segments*12,z/segments*12);
    if(x<segments&&z<segments){const i=z*(segments+1)+x;indices.push(i,i+segments+1,i+1,i+1,i+segments+1,i+segments+2);}
  }
  const normals=[];VertexData.ComputeNormals(positions,indices,normals);const data=new VertexData();data.positions=positions;data.indices=indices;data.normals=normals;data.uvs=uvs;
  const ground=MeshBuilder.CreateGround('battlefield-terrain',{width:size,height:size,subdivisions:1},scene);data.applyToMesh(ground);
  const mat=new StandardMaterial('terrain-material',scene);mat.diffuseColor=new Color3(.34,.38,.29);mat.specularColor=new Color3(.08,.08,.07);ground.material=mat;ground.receiveShadows=true;ground.isPickable=false;
}
function addRoad(scene,name,x,z,width,length,rotation=0){const road=MeshBuilder.CreateGround(name,{width,height:length},scene);road.position.set(x,heightAt(x,z)+.035,z);road.rotation.y=rotation;const mat=new StandardMaterial(name+'-mat',scene);mat.diffuseColor=new Color3(.22,.23,.21);mat.specularColor=Color3.Black();road.material=mat;road.isPickable=false;}
function addRock(scene,x,z,scale){const rock=MeshBuilder.CreatePolyhedron('field-rock',{type:1,size:scale},scene);rock.position.set(x,heightAt(x,z)+scale*.45,z);rock.scaling.y=.65;rock.rotation.set(.2,x*.13,z*.11);const mat=new StandardMaterial('rock-mat',scene);mat.diffuseColor=new Color3(.29,.30,.27);rock.material=mat;rock.isPickable=false;}
export function createBattlefield(scene){createTerrain(scene);addRoad(scene,'main-access-road',0,12,8,70);addRoad(scene,'cross-access-road',0,0,65,7,Math.PI/2);for(let i=0;i<24;i++){const a=i*2.399,r=38+(i%5)*4;addRock(scene,Math.cos(a)*r,Math.sin(a)*r,.8+(i%3)*.35);}}
