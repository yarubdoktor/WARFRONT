import { Engine, Scene, Color4, Vector3, HemisphericLight, DirectionalLight, ArcRotateCamera, StandardMaterial, Color3, ShadowGenerator, PointerEventTypes } from '@babylonjs/core';
import { createBattlefield } from '../world/createBattlefield.js';
import { createBaseBuildings } from '../entities/buildings.js';
import { SelectionSystem } from '../systems/SelectionSystem.js';

export class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.engine = new Engine(canvas, true, { preserveDrawingBuffer: false, stencil: true, adaptToDeviceRatio: true, powerPreference: 'high-performance' });
    this.scene = new Scene(this.engine);
    this.scene.clearColor = new Color4(0.48, 0.57, 0.61, 1);
    this.scene.fogMode = Scene.FOGMODE_EXP; this.scene.fogDensity = 0.0022; this.scene.fogColor = new Color3(0.48, 0.57, 0.61);
    this.camera = new ArcRotateCamera('hybrid-camera', -Math.PI / 2.25, 1.02, 47, Vector3.Zero(), this.scene);
    this.camera.lowerRadiusLimit = 12; this.camera.upperRadiusLimit = 100; this.camera.lowerBetaLimit = 0.22; this.camera.upperBetaLimit = 1.48;
    this.camera.wheelDeltaPercentage = 0.018; this.camera.panningSensibility = 85; this.camera.angularSensibilityX = 850; this.camera.angularSensibilityY = 850; this.camera.inertia = 0.78;
    this.camera.attachControl(this.canvas, true);
    const hemi = new HemisphericLight('ambient-light', new Vector3(0, 1, 0), this.scene); hemi.intensity = 0.72; hemi.groundColor = new Color3(0.23, 0.25, 0.22);
    this.sun = new DirectionalLight('sun', new Vector3(-0.55, -1, 0.35), this.scene); this.sun.position = new Vector3(35, 55, -25); this.sun.intensity = 1.65;
    this.shadowGenerator = new ShadowGenerator(2048, this.sun); this.shadowGenerator.useBlurExponentialShadowMap = true; this.shadowGenerator.blurKernel = 24; this.shadowGenerator.bias = 0.0005;
    createBattlefield(this.scene);
    this.buildings = createBaseBuildings(this.scene, this.shadowGenerator);
    this.selection = new SelectionSystem(this.scene, this.buildings);
    this.scene.onPointerObservable.add((info) => { if (info.type === PointerEventTypes.POINTERPICK) { const pick = info.pickInfo; if (pick?.hit && pick.pickedMesh) this.selection.selectFromMesh(pick.pickedMesh); } });
  }
  async start() { this.engine.runRenderLoop(() => this.scene.render()); document.getElementById('loading')?.classList.add('hidden'); }
  resetCamera() { this.camera.setTarget(Vector3.Zero()); this.camera.alpha = -Math.PI / 2.25; this.camera.beta = 1.02; this.camera.radius = 47; }
  focusBase() { this.camera.setTarget(Vector3.Zero()); this.camera.radius = 28; this.camera.beta = 0.92; }
  resize() { this.engine.resize(); }
}
