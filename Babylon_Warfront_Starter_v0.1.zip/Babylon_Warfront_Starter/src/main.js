import { Game } from './core/Game.js';
import './ui/styles.css';
const canvas = document.getElementById('renderCanvas');
const game = new Game(canvas);
await game.start();
document.getElementById('reset-camera').addEventListener('click', () => game.resetCamera());
document.getElementById('focus-base').addEventListener('click', () => game.focusBase());
window.addEventListener('resize', () => game.resize());
