# WARFRONT — Babylon.js Starter

A modular browser-based 3D strategy prototype foundation.

## Requirements
- Node.js 20+ recommended
- npm

## Run
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

## Included in v0.1
- Babylon.js scene and render loop
- ArcRotate hybrid tactical camera with orbit and zoom
- Procedural rolling battlefield terrain, access roads and rocks
- Directional sunlight, ambient light and soft shadow generator
- Five selectable base structures
- Arabic tactical HUD and responsive layout
- Modular source folders

## Current controls
- Mouse drag / touch drag: camera orbit (Babylon ArcRotateCamera defaults)
- Wheel / pinch: zoom where supported by browser/device
- Select/tap a building: show its information
- HUD buttons: reset camera / focus base

## Next milestones
1. Implement explicit mobile gesture mapping and one-finger pan/orbit mode switching.
2. Import optimized GLB buildings, soldiers and vehicles.
3. Add unit selection, movement orders and rally points.
4. Add placement validation and building construction.
5. Add combat, projectiles, damage, audio and VFX.
6. Add AI and an authoritative multiplayer backend.
7. Profile on target Android phones, then package with Capacitor.

This is a starter prototype, not a finished game. Combat, unit movement, multiplayer and APK packaging are not implemented in this version. Verify performance on target devices before increasing visual quality.
