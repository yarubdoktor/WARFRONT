import { Engine, Scene, Color4, Vector3, HemisphericLight, DirectionalLight, ArcRotateCamera, Color3, ShadowGenerator, PointerEventTypes } from '@babylonjs/core';
import { createBattlefield } from '../world/createBattlefield.js';
import { createBaseBuildings } from '../entities/buildings.js';
import { SelectionSystem } from '../systems/SelectionSystem.js';
import { UnitManager } from '../systems/UnitManager.js';
import { CombatSystem } from '../systems/CombatSystem.js';
import { AISystem } from '../systems/AISystem.js';
import { BuildingPlacementSystem } from '../systems/BuildingPlacementSystem.js';
import { CameraController } from '../systems/CameraController.js';
import { ResourceSystem } from '../systems/ResourceSystem.js';
import { MilitaryAssetSystem } from '../systems/MilitaryAssetSystem.js';

export class Game {
  constructor(canvas) {
    this.canvas=canvas;this.engine=new Engine(canvas,true,{preserveDrawingBuffer:false,stencil:true,adaptToDeviceRatio:true,powerPreference:'high-performance'});
    this.scene=new Scene(this.engine);this.scene.clearColor=new Color4(.48,.57,.61,1);this.scene.fogMode=Scene.FOGMODE_EXP;this.scene.fogDensity=.0022;this.scene.fogColor=new Color3(.48,.57,.61);
    this.camera=new ArcRotateCamera('hybrid-camera',-Math.PI/2.25,1.02,47,Vector3.Zero(),this.scene);this.camera.lowerRadiusLimit=12;this.camera.upperRadiusLimit=100;this.camera.lowerBetaLimit=.22;this.camera.upperBetaLimit=1.48;this.camera.wheelDeltaPercentage=.018;this.camera.panningSensibility=85;this.camera.inertia=.78;this.camera.attachControl(this.canvas,true);
    try{this.camera.inputs.removeByType('ArcRotateCameraPointersInput');}catch{}
    this.cameraController=new CameraController(this.scene,this.camera,this.canvas);
    const hemi=new HemisphericLight('ambient-light',new Vector3(0,1,0),this.scene);hemi.intensity=.72;hemi.groundColor=new Color3(.23,.25,.22);
    this.sun=new DirectionalLight('sun',new Vector3(-.55,-1,.35),this.scene);this.sun.position=new Vector3(35,55,-25);this.sun.intensity=1.65;
    this.shadowGenerator=new ShadowGenerator(2048,this.sun);this.shadowGenerator.useBlurExponentialShadowMap=true;this.shadowGenerator.blurKernel=24;this.shadowGenerator.bias=.0005;
    createBattlefield(this.scene);this.buildings=createBaseBuildings(this.scene,this.shadowGenerator);this.selection=new SelectionSystem(this.scene,this.buildings);
    this.resources=new ResourceSystem();this.resources.subscribe(v=>{const gold=document.getElementById('gold-value');if(gold)gold.textContent=v.gold.toLocaleString('en-US');});this.units=new UnitManager(this.scene,this.shadowGenerator);this.combat=new CombatSystem(this.scene,this.units);this.ai=new AISystem(this.units,this.combat);this.placement=new BuildingPlacementSystem(this.scene,this.buildings,this.shadowGenerator,this.resources);this.militaryAssets=new MilitaryAssetSystem(this.scene,this.shadowGenerator);
    this.bindPicking();this.lastTime=performance.now();
  }
  bindPicking(){this.scene.onPointerObservable.add(info=>{if(info.type!==PointerEventTypes.POINTERPICK)return;const pick=info.pickInfo;if(!pick?.hit||!pick.pickedMesh)return;const mesh=pick.pickedMesh;const root=mesh.metadata?.buildingRoot||(mesh.metadata?.selectable?mesh:null);if(root){this.units.clearSelection();this.selection.selectFromMesh(mesh);return;}if(mesh.metadata?.unit){if(this.units.selected&&this.units.selected.metadata.team!==mesh.metadata.team){this.combat.attack(this.units.selected,mesh);}else{this.selection.clear();this.units.select(mesh);}return;}if(this.placement.type){this.placement.place(pick.pickedPoint);return;}if(this.units.selected&&pick.pickedPoint){this.units.moveSelected(pick.pickedPoint);this.selection.clear();}});}
  async start(){this.engine.runRenderLoop(()=>{const now=performance.now(),dt=Math.min((now-this.lastTime)/1000,.05);this.lastTime=now;this.units.update(dt);this.combat.update(dt);const count=document.getElementById('unit-count');if(count)count.textContent=String(this.units.units.length);this.ai.update(dt);if(this.placement.ghost){const p=this.scene.pointerX!==undefined?this.scene.pick(this.scene.pointerX,this.scene.pointerY,m=>m.name==='battlefield-terrain'):null;if(p?.hit)this.placement.update(p.pickedPoint);}this.scene.render();});document.getElementById('loading')?.classList.add('hidden');}
  resetCamera(){this.camera.setTarget(Vector3.Zero());this.camera.alpha=-Math.PI/2.25;this.camera.beta=1.02;this.camera.radius=47;}
  focusBase(){this.camera.setTarget(Vector3.Zero());this.camera.radius=28;this.camera.beta=.92;}
  resize(){this.engine.resize();}
  dispose(){this.engine.stopRenderLoop();this.scene.dispose();this.engine.dispose();}
}
