# Asset register

## Military vehicle pack
- Pack: Tanks, Military Vehicles and Field Camp
- Publisher: 3DAssets.dev
- License: CC0 1.0 Universal
- Source: https://3dassets.dev/packs/armoured-column-and-field-camp
- Runtime CDN models: Main Battle Tank (23667), Tracked APC (23668), Mobile Rocket Launcher (23671), Supply Truck (23674)
- License permits commercial use and modification without attribution.
- Source metadata states the models are static geometry without rigs or animation clips.
